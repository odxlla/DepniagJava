/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package depniag;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author BIGBOSS
 */

public class CryptoSymetris {
    //String AES_CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";
    private static final String ALGORITMAENKRIPSI = "AES";
    
    String url = "http://localhost/depniag";
    String user;
    String passwd;
    
    public static SecretKey buatkunci() throws NoSuchAlgorithmException {
        SecureRandom sr = new SecureRandom();//buat angka acak
        KeyGenerator kg = KeyGenerator.getInstance(ALGORITMAENKRIPSI);//generate key
        kg.init(256, sr);//membuat key AES 256 bit
        return kg.generateKey();
    }
    public static byte[] createInitializationVector(){ //untuk mencegah pattern attack
        byte[] iv = new byte[16];
        SecureRandom sr = new SecureRandom();
        sr.nextBytes(iv);
        return iv;
    }
    public static byte[] AESEncryption(String plainText, SecretKey secretKey, byte[] iv) throws Exception{
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);
        return cipher.doFinal(plainText.getBytes());
    }
    public static String AESDecryption(byte[] CipherText, SecretKey secretKey, byte[] iv) throws Exception{
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);
        byte[] result = cipher.doFinal(CipherText);
        return new String(result);
    }
    
    public void SimpanKey(byte[] IIV, SecretKey skey) throws Exception{
        CryptoSymetris cr = new CryptoSymetris();
        skey = cr.buatkunci();
        IIV = createInitializationVector();
    }
    public void EncryptAESUrl(String url,byte[] IIV, SecretKey skey)throws Exception{
        SimpanKey(IIV, skey);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(IIV);
        cipher.init(Cipher.ENCRYPT_MODE, skey, ivParameterSpec);
        
    }
    
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        CryptoSymetris cr = new CryptoSymetris();
        SecretKey skey = cr.buatkunci();
        System.out.println("secretKey = "+cr.buatkunci());
        byte[] IIV = createInitializationVector();
        System.out.println("Byte Array IV= "+DatatypeConverter.printHexBinary(IIV));
        //enkripsi
        String plain = "Selamat Datang";
        byte [] cipher = AESEncryption(plain, skey, IIV);
        System.out.println("Ciphertext = "+DatatypeConverter.printHexBinary(cipher));
        //dekripsi
        String dekripsi = AESDecryption(cipher, skey, IIV);
        System.out.println("Hasil Dekripsi = "+dekripsi);
    }
}
